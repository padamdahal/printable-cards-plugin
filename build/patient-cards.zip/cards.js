// Version: 2
// Supports filter event and suffixes

const queryString = window.location.search;
const params = new URLSearchParams(queryString);

const teiId = params.get("teiId");
const enrollmentId = params.get("enrollmentId");
const programId = params.get("programId");
const orgUnitId = params.get("orgUnitId");
const cardId = params.get("cardId");
const eventId = params.get("eventId");
let systemId = null;

window.onload = function () {
	loadDataInCard();
};

async function loadDataInCard() {
	try {
		// Gather enrollmentData
		const url = "../../../api/tracker/enrollments/" + enrollmentId + "?fields=*";
		const enrollmentData = await fetchJSON(url);

		// Split attributes and events
		const events = enrollmentData.events;
		const attributes = enrollmentData.attributes;
		systemId = enrollmentData.attributes.find((a) => a.attribute == 'q3NpuWzGvso').value;
		
		// If an explicit eventId is present in the querystring, fetch that single event.
		// When set, it overrides the "today's events" / "full history" logic below and
		// every section resolves its event placeholders against this one event only.
		let explicitEvent = null;
		
		if (eventId) {
			console.log("Explicit eventId supplied, fetching event: " + eventId);
			const explicitEventUrl = "../../../api/tracker/events/" + eventId + "?fields=*";
			explicitEvent = await fetchJSON(explicitEventUrl);
		}

		let meUrl = "../../../api/me.json?";
		meUrl += "fields=username,firstName,surname,phoneNumber,email,jobTitle,";
		meUrl += "organisationUnits[id,name,shortName,displayName]";
		
		const me = await fetchJSON(meUrl);

		let ouUrl =	"../../../api/organisationUnits/";
		ouUrl += (orgUnitId == 'null' || orgUnitId == undefined) ? me.organisationUnits[0]?.id : orgUnitId;
		ouUrl += "?fields=id,name,displayName,code,";
		ouUrl += "parent[id,name,displayName,code,parent[id,name,displayName,code,parent[id,name,displayName,code,parent[id,name,displayName,code]]]]";
		const orgUnit = await fetchJSON(ouUrl);
		
		var optionSetCollection = {};

		// HTML element to render card inside
		const parentElement = document.getElementById("card");

		console.log("Getting card config");
		const cardConfig = await fetchJSON("../../../api/dataStore/cardDesigner/" + cardId);
		const cardToRender = cardConfig;

		// if cardConfig has path
		if (cardToRender.path) {
			let url = "../../../api/apps/Patient-Cards/" + cardToRender.path;
			url += "?teiId=" + teiId + "&enrollmentId=" + enrollmentId + "&programId=" + programId +	"&orgUnitId=" +	orgUnitId;
			
			window.location.replace(url);
		}

		console.log("Preparing optionSet collection");

		const optionSets = cardToRender.optionSets || {};
		const promises = Object.keys(optionSets).map((dataElementId) => {
			const optionSetId = optionSets[dataElementId];
			if (!optionSetId) return Promise.resolve();
			const url = "../../../api/optionSets/" + optionSetId + "?fields=options[code,name]";
			return fetch(url)
				.then((res) => res.json())
				.then((data) => {
					optionSetCollection[dataElementId] = data.options || [];
				});
		});

		Promise.all(promises).then(() => {
			console.log("Preparing card: " + cardToRender.name);
			var cardSections = cardToRender.sections;
			
			var cardHtmlString = "";
			const regex = /\{.+?\}/g;

			// Tracks every placeholder that actually resolved to a real value, across all
			// sections. Used afterwards to decide whether to keep or drop [[suffix:...]] text.
			const resolvedPlaceholders = new Set();

			// Chooses which event(s) a section should pull placeholder values from.
			// - explicitEvent (via ?eventId=) always wins, for both single and repeatable sections.
			// - otherwise 'today' mode (single sections) filters to events dated today.
			// - otherwise 'history' mode (repeatable sections) returns the full filtered history.
			function getFilteredEvents(section, mode) {
				if (explicitEvent) return [explicitEvent];
				if (!events) return [];
				
				if (mode === "today") {
					const formattedDate = new Date().toISOString().split("T")[0];
					return events.filter(
						(ev) => (!section.programStage || ev.programStage == section.programStage) && ev.occurredAt.substring(0, 10) === formattedDate,
					);
				}
				return section.programStage ? events.filter((ev) => ev.programStage == section.programStage) : events;
			}

			/**
			 * Resolve {uid}, {uid.attr}, {event.attr}, {occurredAt}, {eventIndex}
			 * placeholders in a raw HTML string against a single event.
			 * Only touches tokens that match — all other HTML is left byte-for-byte intact.
			 */
			function resolveEventPlaceholders(html, event, eventIndex) {
				// Matches {anything} — we decide inside whether we can resolve it
				return html.replace(/\{([^}]+)\}/g, (match, expr) => {
					const parts  = expr.split('.');
					const key    = parts[0];
					const subKey = parts[1]; // may be undefined

					// ── Built-ins ──────────────────────────────────────────────
					if (key === 'eventIndex') return String(eventIndex);

					// {event.xxx} — event-level field
					if (key === 'event') {
						const val = event[subKey || 'status'];
						if (val == null) return match;
						resolvedPlaceholders.add(match);
						return val;
					}

					// {occurredAt} / {enrolledAt} — event-level date shorthand
					if (key === 'occurredAt' || key === 'enrolledAt') {
						const val = event[key];
						if (!val) return match;
						resolvedPlaceholders.add(match);
						return isDate(val)
							? NepaliFunctions.AD2BS(val.split('T')[0], 'YYYY-MM-DD') + ' (' + val.split('T')[0] + ')'
							: val;
					}

					// ── Data value lookup by UID ───────────────────────────────
					const dv = (event.dataValues || []).find(d => d.dataElement === key);
					if (!dv) return match; // not found — leave placeholder as-is

					let val;
					const dvKey = subKey || 'value';

					if (Object.hasOwn(optionSetCollection, key)) {
						const opt = optionSetCollection[key]?.find(o => o.code === dv.value);
						val = (!subKey || subKey === 'value')
							? (opt ? opt.name : dv.value)
							: dv[dvKey];
					} else if (dvKey === 'occurredAt' || dvKey === 'enrolledAt') {
						val = event[dvKey];
					} else {
						val = dv[dvKey] !== undefined ? dv[dvKey] : dv.value;
					}

					if (val != null && isDate(String(val))) {
						val = NepaliFunctions.AD2BS(String(val).split('T')[0], 'YYYY-MM-DD') + ' (' + String(val).split('T')[0] + ')';
					}

					if (val != null && val !== '') {
						resolvedPlaceholders.add(match);
						return String(val);
					}
					return match; // leave unreplaced rather than blanking it here
				});
			}

			/**
			 * Find every element with data-repeat="events" inside the section HTML,
			 * get the exact outer HTML of that element as the per-event template,
			 * expand it once per matching event, and splice the results back in place
			 * of the original element — leaving all surrounding HTML untouched.
			 *
			 * Works on any element tag: <tr>, <div>, <li>, etc.
			 * Optional data-stage attribute narrows to a specific program stage.
			 */
			function expandRepeatElements(htmlStr, section) {
				// Use a temporary DOM node so we can querySelector cleanly
				const tmp = document.createElement('div');
				tmp.innerHTML = htmlStr;

				tmp.querySelectorAll('[data-repeat="events"]').forEach(templateEl => {
					const stageFilter = templateEl.getAttribute('data-stage') || section.programStage || null;
					const mode        = section.mode || 'history';

					// Collect events
					let repeatEvents = explicitEvent ? [explicitEvent] : (events || []);
					if (stageFilter) {
						repeatEvents = repeatEvents.filter(ev => ev.programStage === stageFilter);
					}
					if (mode === 'today') {
						const today = new Date().toISOString().split('T')[0];
						repeatEvents = repeatEvents.filter(ev =>
							(ev.occurredAt || '').substring(0, 10) === today
						);
					}
					// Sort newest-first so eventIndex 1 = most recent
					repeatEvents = [...repeatEvents].sort((a, b) =>
						(b.occurredAt || '').localeCompare(a.occurredAt || '')
					);

					// Get the exact outer HTML of the template element,
					// then strip only the data-repeat / data-stage attributes from the clone's tag
					const rawTemplate = templateEl.outerHTML
						.replace(/\s+data-repeat="events"/, '')
						.replace(/\s+data-stage="[^"]*"/, '');

					// Stamp once per event, substituting placeholders each time
					const expandedHtml = repeatEvents
						.map((ev, i) => resolveEventPlaceholders(rawTemplate, ev, i + 1))
						.join('\n');

					// Replace the original element with the expanded HTML in-place
					const range = document.createRange();
					range.selectNode(templateEl);
					const frag = range.createContextualFragment(expandedHtml);
					templateEl.parentNode.replaceChild(frag, templateEl);
				});

				return tmp.innerHTML;
			}

			cardSections.forEach((section) => {
				console.log("Processing card section.");
				var roughHtmlHeader = section.htmlHeader;
				const htmlHeader = roughHtmlHeader != undefined ? roughHtmlHeader.replace(/<\/tbody>\s*<\/table>\s*$/, "") : "";

				var roughHtmlFooter = section.htmlFooter;
				const htmlFooter = roughHtmlFooter ? roughHtmlFooter.replace(/^\s*<table[^>]*>\s*<tbody>/, "") : "";

				// Expand data-repeat="events" elements FIRST, before the plain placeholder loop
				var htmlBody = expandRepeatElements(section.htmlBody, section);

				const valuePlaceholders = htmlBody.match(regex) || [];

				valuePlaceholders.forEach((placeholder) => {
					let key = placeholder.replace(/[{}]/g, "").split(".")[0];
					let valueKey = placeholder.replace(/[{}]/g, "").split(".")[1];
					let value;
					let attr = attributes.find((a) => a.attribute == key);

						// Replace placeholders where it matches attributes
					if (attr) {
							if (Object.hasOwn(optionSetCollection, attr.attribute)) {
								const option = optionSetCollection[attr.attribute]?.find(
									(opt) => opt.code === attr.value,
								);
								const name = option ? option.name : null;

								if (!valueKey || valueKey == "value") {
									value = name;
								} else {
									value = attr[valueKey];
								}
							} else {
								if (!valueKey) {
									valueKey = "value";
								}
								if (valueKey == "occurredAt" || valueKey == "enrolledAt") {
									value = enrollmentData[valueKey];
								} else {
									value = attr[valueKey];
								}
							}

							if (isDate(value)) {
								value = NepaliFunctions.AD2BS(value.split("T")[0], "YYYY-MM-DD") + " (" + value.split("T")[0] + ")";
							}

							if (value && value != undefined) {
								console.log(placeholder + " => " + value);
								resolvedPlaceholders.add(placeholder);
								htmlBody = htmlBody.replaceAll(placeholder, value);
							}
					}

					// Replace placeholders where it matches event/dataValues
					const mode = section.mode ? section.mode : "history";
					const filteredEvents = getFilteredEvents(section, mode);

					filteredEvents.forEach((event) => {
							let eventValue;
							if (key === "event") {
								eventValue = !valueKey ? event["status"] : event[valueKey];
							} else {
								// filter datavalues with dataElement ID
								let dataValue = event.dataValues.find((dv) => dv.dataElement == key);
								if (dataValue) {
									// Check if dataElement key exists in optionSetCollection
									if (Object.hasOwn(optionSetCollection, dataValue.dataElement)) {
										const option = optionSetCollection[dataValue.dataElement]?.find((opt) => opt.code === dataValue.value);
										const name = option ? option.name : null;
										if (!valueKey || valueKey == "value") {
											eventValue = name;
										} else {
											eventValue = dataValue[valueKey];
										}
									} else {
										let dvKey = valueKey || "value";
										if (dvKey == "occurredAt" || dvKey == "enrolledAt") {
											eventValue = event[dvKey];
										} else {
											eventValue = dataValue[dvKey];
										}
									}
								}
							}
							
							if (isDate(eventValue)) {
								eventValue = NepaliFunctions.AD2BS(eventValue.split("T")[0], "YYYY-MM-DD") + " (" + eventValue.split("T")[0] + ")";
							}
							
							if (eventValue) {
								resolvedPlaceholders.add(placeholder);
								htmlBody = htmlBody.replaceAll(placeholder, eventValue);
							}
						});

						// Replace {me.xxx} / {provider.xxx} placeholders with logged-in user info
						if (key === "me" || key === "provider") {
							const meKey = valueKey || "username";
							value = me[meKey];
							if (value) {
								console.log(placeholder + " => " + value);
								resolvedPlaceholders.add(placeholder);
								htmlBody = htmlBody.replaceAll(placeholder, value);
							}
						}

						// Legacy support: bare placeholders matching a top-level me.json field directly,
						// e.g. {firstName} instead of {me.firstName}
						if (Object.keys(me).length != 0 && key !== "me" && key !== "provider") {
							value = me[key];
							if (value) {
								htmlBody = htmlBody.replaceAll(placeholder, value);
								resolvedPlaceholders.add(placeholder);
							}
						}

						// Replace Organisation Unit placeholders (kept in its own variables so it
						// can't be contaminated by valueKey/value mutations from the blocks above)
						let ouValueKey = valueKey || "displayName";
						let ouValue;
						if (key === "ou6") {
							ouValue = orgUnit[ouValueKey];
						} else if (key === "ou5") {
							ouValue = orgUnit?.parent?.[ouValueKey];
						} else if (key === "ou4") {
							ouValue = orgUnit.parent?.parent?.[ouValueKey];
						} else if (key === "ou3") {
							ouValue = orgUnit.parent?.parent?.parent?.[ouValueKey];
						} else if (key === "ou2") {
							ouValue = orgUnit.parent?.parent?.parent?.parent?.[ouValueKey];
						}
						if (ouValue && ouValue != undefined) {
							console.log(placeholder + " => " + ouValue);
							resolvedPlaceholders.add(placeholder);
							htmlBody = htmlBody.replaceAll(placeholder, ouValue);
						}
					});

					cardHtmlString += htmlHeader + htmlBody + htmlFooter;
			});

			// Resolve [[suffix:key.valueKey:suffix text]] markers embedded in card templates.
			const suffixRegex = /\[\[suffix:([^:\]]+):(.*?)\]\]/g;
			cardHtmlString = cardHtmlString.replace(
				suffixRegex, (match, key, text) => {
					return resolvedPlaceholders.has("{" + key + "}") ? text : "";
				},
			);

			// Growthchart
			var svg = GrowthChart.renderFromEvents({
				sex: attributes.find((a) => a.attribute == 'RzyHxE71iyC').value,
				dob: attributes.find((a) => a.attribute == 'i607dSgfm4F').value,
				events: events,
				weightDeUid: 'J6QgfoUf5my'
			});
			
			cardHtmlString = GrowthChart.injectPlaceholder(cardHtmlString, '{growthChart}', svg);

			// load QR if required
			var qrCode = QRCodeHelper.renderFromClientId(systemId);
			cardHtmlString = QRCodeHelper.injectPlaceholder(cardHtmlString, '{QRCode}',	qrCode);

			// clean placeholders that were not replaced with real values
			const placeholdersToClean = cardHtmlString.match(regex) || [];
			placeholdersToClean.forEach((placeholder) => {
				cardHtmlString = cardHtmlString.replaceAll(placeholder, "");
			});
			
			parentElement.innerHTML = cardHtmlString;
			
		});
	} catch (e) {
		console.log("Error: " + e.message);
		console.error(e);
	}
}

var QRCodeHelper = {
		renderFromClientId: function (clientId) {
				if (!clientId) {
						return '';
				}
				var container = document.createElement('div');
				new QRCode(container, {
						text: String(clientId),
						width: 65,
						height: 65,
						correctLevel: QRCode.CorrectLevel.M
				});
				var canvas = container.querySelector('canvas');
				if (canvas) {
					return '<img src="' + canvas.toDataURL('image/png') + '" width="65" height="65">';
				}

				var img = container.querySelector('img');
				if (img) {
					return '<img src="' + img.src + '" width="65" height="65">';
				}
				return '';
		},

		injectPlaceholder: function (html, placeholder, content) {
				return html.replace(
						new RegExp(
								placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'),
								'g'
						),
						content || ''
				);
		}
};

async function fetchJSON(url) {
	const res = await fetch(url);
	if (!res.ok) throw new Error("DHIS2 API fetch failed");
	return res.json();
}

function isDate(value) {
	value = value ? value.substring(0, 10) : "";
	return /^\d{4}-\d{2}-\d{2}$/.test(value) && !isNaN(new Date(value).getTime());
}
